
package inventory;

public interface InventoryManagement {
    default void displayProducts(Product[] products) {
        if (products == null || products.length == 0) {
            System.out.println("There are no products in the inventory.");
            return;
        }

        System.out.println("Products in the inventory:");
        for (Product product : products) {
            System.out.println("- " + product.getName() + " (Price: $" + product.getPrice() +
                    ", Quantity: " + product.getQuantity() + ")");
        }
    }

    static Product searchProduct(Product[] products, String name) throws ProductNotFoundException {
        if (products == null || products.length == 0) {
            throw new ProductNotFoundException("There are no products in the inventory.");
        }

        for (Product product : products) {
            if (product.getName().equalsIgnoreCase(name)) {
                return product;
            }
        }

        throw new ProductNotFoundException("Product not found in the inventory: " + name);
    }
}