package inventory;

public class Inventory implements InventoryManagement {
    public Product[] products;
    private int numOfProducts;
    public Inventory(int capacity) {
        products = new Product[capacity];
        numOfProducts = 0;
    }
    public void addProduct(Product product) {
        if (numOfProducts == products.length) {
            System.out.println("The inventory is full.");
            return;
        }
        products[numOfProducts++] = product;
        System.out.println("Product added to the inventory: " + product.getName());
    }
    public void removeProduct(String name) throws ProductNotFoundException {
        if (numOfProducts == 0) {
            throw new ProductNotFoundException("There are no products in the inventory.");
        }
        int index = -1;
        for (int i = 0; i < numOfProducts; i++) {
            if (products[i].getName().equalsIgnoreCase(name)) {
                index = i;
                break;
            }
        }
        if (index == -1) {
            throw new ProductNotFoundException("Product not found in the inventory: " + name);
        }

        for (int i = index; i < numOfProducts - 1; i++) {
            products[i] = products[i + 1];
        }

        products[--numOfProducts] = null;
        System.out.println("Product removed from the inventory: " + name);
    }
    public void updateProduct(String name, double price, int quantity) throws ProductNotFoundException {
        Product product = InventoryManagement.searchProduct(products, name);
        product.price = price;
        product.quantity = quantity;
        System.out.println("Product updated in the inventory: " + name);
    }
}