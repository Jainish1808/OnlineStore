package inventory;

public class Movie extends Product {
    private String director;

    public Movie(String name, double price, int quantity, String director) {
        super(name, price, quantity);
        this.director = director;
    }

    public String getDirector() {
        return director;
    }

    @Override
    public String toString() {
        return super.toString() + ", Director: " + director;
    }
}