package src;
import inventory.*;

import java.util.Scanner;

public class OnlineStore {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        Inventory inventory = new Inventory(3); // create an inventory with capacity of 10

        // add some products to the inventory
        inventory.addProduct(new Book("The Hitchhiker's Guide to the Galaxy", 12.99, 5, "Douglas Adams"));
        inventory.addProduct(new Book("To Kill a Mockingbird", 8.99, 3, "Harper Lee"));
        inventory.addProduct(new Movie("The Godfather", 14.99, 2, "Francis Ford Coppola"));

        while (true) {
            System.out.println("\nWhat would you like to do?");
            System.out.println("1. Display products in inventory");
            System.out.println("2. Add a new product to inventory");
            System.out.println("3. Remove a product from inventory");
            System.out.println("4. Update a product in inventory");
            System.out.println("5. Search for a product in inventory");
            System.out.println("0. Exit");

            int choice = scanner.nextInt();
            scanner.nextLine(); // consume the newline character

            switch (choice) {
                case 1:
                    inventory.displayProducts(inventory.products);
                    break;
                case 2:
                    System.out.println("Enter the product type (book/movie):");
                    String type = scanner.nextLine();
                    System.out.println("Enter the product name:");
                    String name = scanner.nextLine();
                    System.out.println("Enter the product price:");
                    double price = scanner.nextDouble();
                    System.out.println("Enter the product quantity:");
                    int quantity = scanner.nextInt();
                    scanner.nextLine(); // consume the newline character

                    if (type.equalsIgnoreCase("book")) {
                        System.out.println("Enter the author name:");
                        String author = scanner.nextLine();
                        inventory.addProduct(new Book(name, price, quantity, author));
                    } else if (type.equalsIgnoreCase("movie")) {
                        System.out.println("Enter the director name:");
                        String director = scanner.nextLine();
                        inventory.addProduct(new Movie(name, price, quantity, director));
                    } else {
                        System.out.println("Invalid product type.");
                    }
                    break;
                case 3:
                    System.out.println("Enter the product name:");
                    name = scanner.nextLine();
                    try {
                        inventory.removeProduct(name);
                    } catch (ProductNotFoundException e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 4:
                    System.out.println("Enter the product name:");
                    name = scanner.nextLine();
                    System.out.println("Enter the new price:");
                    price = scanner.nextDouble();
                    System.out.println("Enter the new quantity:");
                    quantity = scanner.nextInt();
                    scanner.nextLine(); // consume the newline character
                    try {
                        inventory.updateProduct(name, price, quantity);
                    } catch (ProductNotFoundException e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 5:
                    System.out.println("Enter the product name:");
                    name = scanner.nextLine();
                    try {
                        Product product = InventoryManagement.searchProduct(inventory.products, name);
                        System.out.println("Product found in inventory:");
                        System.out.println("- " + product.getName() + " (Price: $" + product.getPrice() +
                                ", Quantity: " + product.getQuantity() + ")");
                    } catch (ProductNotFoundException e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 0:
                    System.out.println("Thank you for using our online store!");
                    System.exit(0);
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }
}